my_string = "Pizza con piña"

for char in range (len(my_string)-1,-1,-1):
    print(f"{my_string[char]}")