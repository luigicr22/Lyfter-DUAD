hotel = {
	"name" : "holiday inn",
    "stars" : 4,
    "room_details" : [
        {"room" : 101, "floor":1, "price":150},
        {"room" : 102, "floor":1, "price":160},
        {"room" : 201, "floor":2, "price":200},
        {"room" : 202, "floor":2, "price":210},
        ]
}

print(hotel)