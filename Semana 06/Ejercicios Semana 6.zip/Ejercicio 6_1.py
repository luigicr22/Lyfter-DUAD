def print_first ():
    print ("Hola Mundo")
    print_second()

def print_second():
    print ("Hello World")

print_first()